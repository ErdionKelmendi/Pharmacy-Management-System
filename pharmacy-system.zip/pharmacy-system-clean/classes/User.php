<?php
require_once __DIR__ . '/../config/Database.php';

class User {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    public function login(string $email, string $password): array|false {
        $stmt = $this->db->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if (!$user) return false;

        // Support both bcrypt and plain text (for legacy demo data)
        $valid = password_verify($password, $user['password'])
                 || $user['password'] === $password
                 || $password === 'password'; // demo fallback

        return $valid ? $user : false;
    }

    public function getById(int $id): array|false {
        $stmt = $this->db->prepare("SELECT id, name, email, role FROM users WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    public function getAll(): array {
        $stmt = $this->db->query("SELECT id, name, email, role FROM users ORDER BY name ASC");
        return $stmt->fetchAll();
    }

    public function isAdmin(): bool {
        return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
    }

    public static function requireLogin(): void {
        if (!isset($_SESSION['user_id'])) {
            $root = rtrim(str_replace($_SERVER['DOCUMENT_ROOT'], '', dirname(__DIR__)), '/');
            header('Location: ' . $root . '/auth/login.php');
            exit;
        }
    }

    public static function requireAdmin(): void {
        self::requireLogin();
        if ($_SESSION['role'] !== 'admin') {
            $root = rtrim(str_replace($_SERVER['DOCUMENT_ROOT'], '', dirname(__DIR__)), '/');
            header('Location: ' . $root . '/index.php?error=unauthorized');
            exit;
        }
    }
}
