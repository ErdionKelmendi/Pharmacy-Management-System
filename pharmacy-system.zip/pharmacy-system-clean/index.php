<?php
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: ' . rtrim(str_replace($_SERVER['DOCUMENT_ROOT'], '', __DIR__), '/') . '/auth/login.php'); exit; }

require_once __DIR__ . '/config/Database.php';
require_once __DIR__ . '/classes/Medicine.php';
require_once __DIR__ . '/classes/Customer.php';
require_once __DIR__ . '/classes/Sale.php';

$medicine = new Medicine();
$customer = new Customer();
$sale     = new Sale();

$totalMeds    = $medicine->getCount();
$totalCusts   = $customer->getCount();
$totalSales   = $sale->getCount();
$todayRev     = $sale->getTodayRevenue();
$totalRev     = $sale->getTotalRevenue();
$invValue     = $medicine->getTotalValue();
$lowStock     = $medicine->getLowStock(15);
$expiringSoon = $medicine->getExpiringSoon(60);
$recentSales  = $sale->getRecentSales(6);
$topMeds      = $sale->getTopMedicines(5);

$pageTitle = 'Dashboard';
include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/navbar.php';
?>

<main class="p-6 space-y-6">

  <!-- Stat Cards -->
  <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
    <?php
    $stats = [
      ['label'=>'Total Medicines',  'value'=>$totalMeds,                         'icon'=>'💊', 'bg'=>'bg-blue-50',   'ic'=>'bg-blue-100 text-blue-600'],
      ['label'=>"Today's Revenue",  'value'=>'$'.number_format($todayRev,2),      'icon'=>'💰', 'bg'=>'bg-green-50',  'ic'=>'bg-green-100 text-green-600'],
      ['label'=>'Total Sales',      'value'=>$totalSales,                         'icon'=>'🧾', 'bg'=>'bg-amber-50',  'ic'=>'bg-amber-100 text-amber-600'],
      ['label'=>'Customers',        'value'=>$totalCusts,                         'icon'=>'👥', 'bg'=>'bg-purple-50', 'ic'=>'bg-purple-100 text-purple-600'],
    ];
    foreach ($stats as $s): ?>
    <div class="bg-white rounded-2xl border border-slate-100 shadow-sm p-5 flex items-center gap-4">
      <div class="w-12 h-12 rounded-xl <?= $s['ic'] ?> flex items-center justify-center text-xl flex-shrink-0"><?= $s['icon'] ?></div>
      <div>
        <div class="text-2xl font-bold text-slate-900"><?= $s['value'] ?></div>
        <div class="text-xs text-slate-500 font-medium mt-0.5"><?= $s['label'] ?></div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- Revenue + Inventory value -->
  <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
    <div class="bg-white rounded-2xl border border-slate-100 shadow-sm p-5 flex items-center justify-between">
      <div>
        <div class="text-xs text-slate-500 font-semibold uppercase tracking-wider mb-1">Total Revenue</div>
        <div class="text-3xl font-extrabold text-green-600">$<?= number_format($totalRev, 2) ?></div>
      </div>
      <div class="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center text-2xl">📈</div>
    </div>
    <div class="bg-white rounded-2xl border border-slate-100 shadow-sm p-5 flex items-center justify-between">
      <div>
        <div class="text-xs text-slate-500 font-semibold uppercase tracking-wider mb-1">Inventory Value</div>
        <div class="text-3xl font-extrabold text-blue-600">$<?= number_format($invValue, 2) ?></div>
      </div>
      <div class="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center text-2xl">📦</div>
    </div>
  </div>

  <!-- Alerts -->
  <?php if (!empty($lowStock)): ?>
  <div class="alert-auto bg-amber-50 border border-amber-200 rounded-xl px-5 py-4 flex items-start gap-3">
    <span class="text-xl mt-0.5">⚠️</span>
    <div>
      <div class="font-semibold text-amber-800 text-sm"><?= count($lowStock) ?> medicine(s) low on stock</div>
      <div class="text-amber-700 text-xs mt-1"><?= implode(', ', array_column(array_slice($lowStock,0,5), 'name')) ?><?= count($lowStock)>5?'…':'' ?></div>
    </div>
  </div>
  <?php endif; ?>
  <?php if (!empty($expiringSoon)): ?>
  <div class="alert-auto bg-red-50 border border-red-200 rounded-xl px-5 py-4 flex items-start gap-3">
    <span class="text-xl mt-0.5">⏰</span>
    <div>
      <div class="font-semibold text-red-800 text-sm"><?= count($expiringSoon) ?> medicine(s) expiring within 60 days</div>
      <div class="text-red-700 text-xs mt-1"><?= implode(', ', array_column(array_slice($expiringSoon,0,5), 'name')) ?></div>
    </div>
  </div>
  <?php endif; ?>

  <!-- Bottom Grid -->
  <div class="grid grid-cols-1 xl:grid-cols-3 gap-6">

    <!-- Recent Sales (takes 2 cols) -->
    <div class="xl:col-span-2 bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
      <div class="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
        <h3 class="font-bold text-slate-800">Recent Sales</h3>
        <a href="sales/index.php" class="text-blue-600 text-sm font-medium hover:underline">View All →</a>
      </div>
      <?php if (empty($recentSales)): ?>
      <div class="py-16 text-center text-slate-400">
        <div class="text-4xl mb-3">🧾</div>
        <div class="font-medium">No sales recorded yet</div>
      </div>
      <?php else: ?>
      <div class="overflow-x-auto">
        <table class="w-full text-sm">
          <thead class="bg-slate-50 text-xs text-slate-500 uppercase tracking-wider">
            <tr>
              <th class="px-5 py-3 text-left font-semibold">Medicine</th>
              <th class="px-5 py-3 text-left font-semibold">Customer</th>
              <th class="px-5 py-3 text-left font-semibold">Qty</th>
              <th class="px-5 py-3 text-left font-semibold">Total</th>
              <th class="px-5 py-3 text-left font-semibold">Date</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-slate-50">
            <?php foreach ($recentSales as $s): ?>
            <tr class="hover:bg-slate-50 transition-colors">
              <td class="px-5 py-3.5 font-semibold text-slate-800"><?= htmlspecialchars($s['medicine_name'] ?? '—') ?></td>
              <td class="px-5 py-3.5 text-slate-500"><?= htmlspecialchars($s['customer_name'] ?? '—') ?></td>
              <td class="px-5 py-3.5 text-slate-600"><?= $s['quantity'] ?></td>
              <td class="px-5 py-3.5 font-bold text-green-600">$<?= number_format($s['total_price'],2) ?></td>
              <td class="px-5 py-3.5 text-slate-400 text-xs"><?= date('M d, H:i', strtotime($s['sale_date'])) ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?php endif; ?>
    </div>

    <!-- Side panel -->
    <div class="space-y-4">

      <!-- Top Selling -->
      <div class="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
        <div class="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
          <h3 class="font-bold text-slate-800">Top Selling</h3>
          <span class="text-xs bg-blue-100 text-blue-700 font-semibold px-2.5 py-1 rounded-full">All time</span>
        </div>
        <div class="px-5 py-3 divide-y divide-slate-50">
          <?php if (empty($topMeds)): ?>
          <p class="text-slate-400 text-sm py-4 text-center">No data yet</p>
          <?php else: foreach ($topMeds as $i => $m): ?>
          <div class="flex items-center gap-3 py-3">
            <div class="w-7 h-7 rounded-lg bg-blue-50 text-blue-700 font-bold text-xs flex items-center justify-center"><?= $i+1 ?></div>
            <div class="flex-1 min-w-0">
              <div class="text-sm font-semibold text-slate-800 truncate"><?= htmlspecialchars($m['name']) ?></div>
              <div class="text-xs text-slate-400"><?= $m['total_sold'] ?> units</div>
            </div>
            <div class="text-sm font-bold text-green-600">$<?= number_format($m['revenue'],2) ?></div>
          </div>
          <?php endforeach; endif; ?>
        </div>
      </div>

      <!-- Quick Actions -->
      <div class="bg-white rounded-2xl border border-slate-100 shadow-sm p-4 space-y-2">
        <h3 class="font-bold text-slate-800 mb-3">Quick Actions</h3>
        <a href="sales/create.php" class="flex items-center gap-2 justify-center w-full bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold py-2.5 rounded-xl transition-colors">🛒 Record New Sale</a>
        <a href="medicines/create.php" class="flex items-center gap-2 justify-center w-full bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm font-semibold py-2.5 rounded-xl transition-colors">💊 Add Medicine</a>
        <a href="customers/create.php" class="flex items-center gap-2 justify-center w-full bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm font-semibold py-2.5 rounded-xl transition-colors">👤 Add Customer</a>
      </div>

    </div>
  </div>

</main>

<?php include __DIR__ . '/includes/footer.php'; ?>
