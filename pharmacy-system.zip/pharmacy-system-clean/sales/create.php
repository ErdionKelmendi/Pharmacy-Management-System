<?php
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: ' . rtrim(str_replace($_SERVER['DOCUMENT_ROOT'], '', dirname(__DIR__)), '/') . '/auth/login.php'); exit; }
require_once __DIR__ . '/../config/Database.php';
require_once __DIR__ . '/../classes/Medicine.php';
require_once __DIR__ . '/../classes/Customer.php';
require_once __DIR__ . '/../classes/Sale.php';

$medicines = (new Medicine())->getAll();
$customers = (new Customer())->getAll();
$errors=[]; $success=null; $saleTotal=null;

if ($_SERVER['REQUEST_METHOD']==='POST') {
    $med_id = (int)($_POST['medicine_id']??0);
    $cust_id= (int)($_POST['customer_id']??0);
    $qty    = (int)($_POST['quantity']??0);
    if (!$med_id)  $errors[]='Please select a medicine.';
    if (!$cust_id) $errors[]='Please select a customer.';
    if ($qty<=0)   $errors[]='Quantity must be at least 1.';
    if (!$errors) {
        $result=(new Sale())->create($med_id,$cust_id,(int)$_SESSION['user_id'],$qty);
        if ($result['success']) { $success=$result['message']; $saleTotal=$result['total']; $medicines=(new Medicine())->getAll(); }
        else $errors[]=$result['message'];
    }
}

$medJson=json_encode(array_column(
    array_map(fn($m)=>['id'=>$m['id'],'price'=>$m['price'],'stock'=>$m['quantity']],$medicines),null,'id'
));
$pageTitle='New Sale';
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
?>

<main class="p-6 space-y-5">

  <div class="flex items-start justify-between">
    <div>
      <h2 class="text-2xl font-bold text-slate-900">Record New Sale</h2>
      <p class="text-slate-500 text-sm mt-0.5">Select medicine, customer and quantity</p>
    </div>
    <a href="index.php" class="inline-flex items-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm font-semibold px-4 py-2.5 rounded-xl transition-colors">🧾 Sales History</a>
  </div>

  <?php if ($success): ?>
  <div class="alert-auto bg-green-50 border border-green-200 rounded-xl px-5 py-4 flex items-center gap-3">
    <span class="text-2xl">✅</span>
    <div>
      <div class="font-semibold text-green-800">Sale recorded successfully!</div>
      <div class="text-green-700 text-sm"><?= htmlspecialchars($success) ?></div>
    </div>
    <div class="ml-auto text-right">
      <div class="text-xs text-green-600 uppercase tracking-wider font-semibold">Total</div>
      <div class="text-2xl font-extrabold text-green-700">$<?= number_format($saleTotal,2) ?></div>
    </div>
  </div>
  <?php endif; ?>

  <?php foreach ($errors as $e): ?>
  <div class="bg-red-50 border border-red-200 rounded-xl px-4 py-3 text-sm text-red-700 flex items-center gap-2">⚠️ <?= htmlspecialchars($e) ?></div>
  <?php endforeach; ?>

  <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">

    <!-- Form -->
    <div class="lg:col-span-2 bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
      <div class="px-6 py-4 border-b border-slate-100">
        <h3 class="font-bold text-slate-800">🛒 Sale Details</h3>
      </div>
      <div class="px-6 py-6">
        <form method="POST" id="saleForm" class="space-y-5">
          <div>
            <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Medicine *</label>
            <select name="medicine_id" id="medicine_id" required onchange="calc()"
                    class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white">
              <option value="">— Select medicine —</option>
              <?php foreach ($medicines as $m): ?>
              <option value="<?= $m['id'] ?>" <?= ($m['quantity']==0?'disabled':'') . (isset($_POST['medicine_id'])&&$_POST['medicine_id']==$m['id']?'selected':'') ?>>
                <?= htmlspecialchars($m['name']) ?> — $<?= number_format($m['price'],2) ?> (Stock: <?= $m['quantity'] ?>)<?= $m['quantity']==0?' — OUT OF STOCK':'' ?>
              </option>
              <?php endforeach; ?>
            </select>
          </div>
          <div>
            <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Customer *</label>
            <select name="customer_id" required
                    class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white">
              <option value="">— Select customer —</option>
              <?php foreach ($customers as $c): ?>
              <option value="<?= $c['id'] ?>" <?= isset($_POST['customer_id'])&&$_POST['customer_id']==$c['id']?'selected':'' ?>>
                <?= htmlspecialchars($c['name']) ?><?= $c['phone']?" — {$c['phone']}":'' ?>
              </option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="grid grid-cols-2 gap-4">
            <div>
              <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Quantity *</label>
              <input type="number" name="quantity" id="qty" min="1" required
                     value="<?= (int)($_POST['quantity']??1) ?>" oninput="calc()"
                     class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"/>
            </div>
            <div>
              <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Unit Price</label>
              <input type="text" id="unit_price" readonly value="—"
                     class="w-full border border-slate-100 bg-slate-50 rounded-xl px-4 py-2.5 text-sm text-slate-500 cursor-default"/>
            </div>
          </div>

          <div id="stock_warn" class="hidden bg-amber-50 border border-amber-200 rounded-xl px-4 py-3 text-sm text-amber-700 flex items-center gap-2">
            ⚠️ <span id="stock_warn_text"></span>
          </div>

          <div class="flex gap-3 pt-2 border-t border-slate-100">
            <button type="submit" class="bg-emerald-600 hover:bg-emerald-700 text-white font-semibold px-6 py-2.5 rounded-xl text-sm transition-colors shadow-sm">✓ Complete Sale</button>
            <a href="index.php" class="bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold px-6 py-2.5 rounded-xl text-sm transition-colors">Cancel</a>
          </div>
        </form>
      </div>
    </div>

    <!-- Live Preview -->
    <div class="space-y-4">
      <div class="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
        <div class="px-5 py-4 border-b border-slate-100">
          <h3 class="font-bold text-slate-800">Live Preview</h3>
        </div>
        <div class="px-5 py-8 text-center">
          <div class="text-xs text-slate-400 uppercase tracking-widest font-semibold mb-2">Estimated Total</div>
          <div id="preview_total" class="text-5xl font-extrabold text-blue-600">$0.00</div>
          <div id="preview_detail" class="text-slate-400 text-sm mt-2">Select medicine & qty</div>
        </div>
      </div>
      <div class="bg-white rounded-2xl border border-slate-100 shadow-sm p-4 space-y-2">
        <a href="../customers/create.php" class="flex items-center justify-center gap-2 w-full bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm font-semibold py-2.5 rounded-xl transition-colors">👤 New Customer</a>
        <a href="../medicines/index.php"  class="flex items-center justify-center gap-2 w-full bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm font-semibold py-2.5 rounded-xl transition-colors">💊 View Stock</a>
      </div>
    </div>

  </div>
</main>

<script>
const meds = <?= $medJson ?>;
function calc() {
  const id  = document.getElementById('medicine_id').value;
  const qty = parseInt(document.getElementById('qty').value)||0;
  const pt  = document.getElementById('preview_total');
  const pd  = document.getElementById('preview_detail');
  const up  = document.getElementById('unit_price');
  const sw  = document.getElementById('stock_warn');
  const st  = document.getElementById('stock_warn_text');
  if (!id||!meds[id]) { pt.textContent='$0.00'; pd.textContent='Select medicine & qty'; up.value='—'; sw.classList.add('hidden'); return; }
  const m=meds[id], total=m.price*qty;
  up.value='$'+parseFloat(m.price).toFixed(2);
  pt.textContent='$'+total.toFixed(2);
  pd.textContent=qty+' × $'+parseFloat(m.price).toFixed(2);
  if (qty>m.stock) { sw.classList.remove('hidden'); st.textContent='Only '+m.stock+' units available.'; }
  else sw.classList.add('hidden');
}
document.addEventListener('DOMContentLoaded', calc);
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
