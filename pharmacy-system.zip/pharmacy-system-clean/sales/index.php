<?php
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: ' . rtrim(str_replace($_SERVER['DOCUMENT_ROOT'], '', dirname(__DIR__)), '/') . '/auth/login.php'); exit; }
require_once __DIR__ . '/../config/Database.php';
require_once __DIR__ . '/../classes/Sale.php';

$sale      = new Sale();
$sales     = $sale->getAll();
$totalRev  = $sale->getTotalRevenue();
$todayRev  = $sale->getTodayRevenue();
$count     = $sale->getCount();
$pageTitle = 'Sales History';
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
?>

<main class="p-6 space-y-5">

  <div class="flex items-start justify-between">
    <div>
      <h2 class="text-2xl font-bold text-slate-900">Sales History</h2>
      <p class="text-slate-500 text-sm mt-0.5"><?= $count ?> total transactions</p>
    </div>
    <a href="create.php" class="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold px-4 py-2.5 rounded-xl shadow transition-colors">＋ New Sale</a>
  </div>

  <!-- Stats -->
  <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
    <div class="bg-white rounded-2xl border border-slate-100 shadow-sm p-5 flex items-center gap-4">
      <div class="w-12 h-12 rounded-xl bg-green-100 text-green-600 flex items-center justify-center text-xl flex-shrink-0">💰</div>
      <div><div class="text-2xl font-bold text-slate-900">$<?= number_format($totalRev,2) ?></div><div class="text-xs text-slate-500 font-medium mt-0.5">All-Time Revenue</div></div>
    </div>
    <div class="bg-white rounded-2xl border border-slate-100 shadow-sm p-5 flex items-center gap-4">
      <div class="w-12 h-12 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center text-xl flex-shrink-0">☀️</div>
      <div><div class="text-2xl font-bold text-slate-900">$<?= number_format($todayRev,2) ?></div><div class="text-xs text-slate-500 font-medium mt-0.5">Today's Revenue</div></div>
    </div>
    <div class="bg-white rounded-2xl border border-slate-100 shadow-sm p-5 flex items-center gap-4">
      <div class="w-12 h-12 rounded-xl bg-amber-100 text-amber-600 flex items-center justify-center text-xl flex-shrink-0">🧾</div>
      <div><div class="text-2xl font-bold text-slate-900"><?= $count ?></div><div class="text-xs text-slate-500 font-medium mt-0.5">Transactions</div></div>
    </div>
  </div>

  <?php if (empty($sales)): ?>
  <div class="bg-white rounded-2xl border border-slate-100 shadow-sm py-20 text-center">
    <div class="text-5xl mb-4">🧾</div>
    <div class="text-lg font-bold text-slate-700 mb-1">No sales yet</div>
    <div class="text-slate-400 text-sm mb-4">Record your first sale.</div>
    <a href="create.php" class="inline-block bg-blue-600 text-white text-sm font-semibold px-5 py-2.5 rounded-xl">Record Sale</a>
  </div>

  <?php else: ?>
  <div class="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
    <div class="overflow-x-auto">
      <table class="w-full text-sm">
        <thead class="bg-slate-50 text-xs text-slate-500 uppercase tracking-wider border-b border-slate-100">
          <tr>
            <th class="px-5 py-3.5 text-left font-semibold">#</th>
            <th class="px-5 py-3.5 text-left font-semibold">Medicine</th>
            <th class="px-5 py-3.5 text-left font-semibold">Customer</th>
            <th class="px-5 py-3.5 text-left font-semibold">Cashier</th>
            <th class="px-5 py-3.5 text-left font-semibold">Qty</th>
            <th class="px-5 py-3.5 text-left font-semibold">Unit Price</th>
            <th class="px-5 py-3.5 text-left font-semibold">Total</th>
            <th class="px-5 py-3.5 text-left font-semibold">Date</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-slate-50">
          <?php foreach ($sales as $s): ?>
          <tr class="hover:bg-slate-50 transition-colors">
            <td class="px-5 py-3.5 text-slate-400 text-xs"><?= $s['id'] ?></td>
            <td class="px-5 py-3.5 font-semibold text-slate-800"><?= htmlspecialchars($s['medicine_name']??'—') ?></td>
            <td class="px-5 py-3.5 text-slate-500"><?= htmlspecialchars($s['customer_name']??'—') ?></td>
            <td class="px-5 py-3.5">
              <div class="flex items-center gap-2">
                <div class="w-6 h-6 rounded-full bg-blue-500 flex items-center justify-center text-white font-bold text-[10px]">
                  <?= strtoupper(substr($s['user_name']??'U',0,1)) ?>
                </div>
                <span class="text-slate-500 text-xs"><?= htmlspecialchars($s['user_name']??'—') ?></span>
              </div>
            </td>
            <td class="px-5 py-3.5 text-slate-600"><?= $s['quantity'] ?></td>
            <td class="px-5 py-3.5 text-slate-400 text-xs">
              $<?= $s['quantity']>0 ? number_format($s['total_price']/$s['quantity'],2) : '0.00' ?>
            </td>
            <td class="px-5 py-3.5 font-bold text-green-600">$<?= number_format($s['total_price'],2) ?></td>
            <td class="px-5 py-3.5 text-slate-400 text-xs"><?= date('M d, Y H:i', strtotime($s['sale_date'])) ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
        <tfoot class="bg-slate-50 border-t-2 border-slate-200">
          <tr>
            <td colspan="6" class="px-5 py-3.5 text-xs font-bold text-slate-500 uppercase tracking-wider">Grand Total</td>
            <td class="px-5 py-3.5 text-lg font-extrabold text-green-600">$<?= number_format($totalRev,2) ?></td>
            <td></td>
          </tr>
        </tfoot>
      </table>
    </div>
  </div>
  <?php endif; ?>

</main>

<?php include __DIR__ . '/../includes/footer.php'; ?>
