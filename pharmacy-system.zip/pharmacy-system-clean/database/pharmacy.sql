-- Drop database if it exists
DROP DATABASE IF EXISTS pharmacy;

-- Create database
CREATE DATABASE pharmacy;
USE pharmacy;

-- =========================
-- USERS TABLE
-- =========================
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    password VARCHAR(255),
    role ENUM('admin', 'user') DEFAULT 'user'
);

-- =========================
-- MEDICINES TABLE
-- =========================
CREATE TABLE medicines (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    quantity INT DEFAULT 0,
    expiry_date DATE
);

-- =========================
-- CUSTOMERS TABLE
-- =========================
CREATE TABLE customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150),
    phone VARCHAR(20)
);

-- =========================
-- SALES TABLE
-- =========================
CREATE TABLE sales (
    id INT AUTO_INCREMENT PRIMARY KEY,
    medicine_id INT,
    customer_id INT,
    user_id INT,
    quantity INT,
    total_price DECIMAL(10,2),
    sale_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (medicine_id) REFERENCES medicines(id) ON DELETE SET NULL,
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- =========================
-- STOCK TABLE
-- =========================
CREATE TABLE stock (
    id INT AUTO_INCREMENT PRIMARY KEY,
    medicine_id INT,
    change_type ENUM('IN', 'OUT'),
    quantity INT,
    date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    note TEXT,

    FOREIGN KEY (medicine_id) REFERENCES medicines(id) ON DELETE CASCADE
);

-- =========================
-- SAMPLE DATA
-- =========================

-- Users (passwords stored as bcrypt in production, plain for demo)
INSERT INTO users (name, email, password, role) VALUES
('Admin', 'admin@pharmacy.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin'),
('Erdion', 'erdion@pharmacy.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'user');

-- Medicines
INSERT INTO medicines (name, price, quantity, expiry_date) VALUES
('Paracetamol 500mg', 2.50, 100, '2026-12-31'),
('Ibuprofen 400mg', 3.00, 80, '2026-10-15'),
('Amoxicillin 250mg', 8.75, 60, '2026-08-20'),
('Metformin 500mg', 5.20, 45, '2027-03-10'),
('Atorvastatin 20mg', 12.00, 30, '2026-11-01'),
('Omeprazole 20mg', 6.50, 55, '2027-01-15');

-- Customers
INSERT INTO customers (name, phone) VALUES
('Walk-in Customer', '000000000'),
('Alice Smith', '123456789'),
('Bob Johnson', '987654321'),
('Carol White', '555123456');

-- Example Sales
INSERT INTO sales (medicine_id, customer_id, user_id, quantity, total_price) VALUES
(1, 1, 1, 2, 5.00),
(2, 2, 1, 3, 9.00),
(3, 3, 2, 1, 8.75);

-- Stock movements
INSERT INTO stock (medicine_id, change_type, quantity, note) VALUES
(1, 'OUT', 2, 'Sold to customer'),
(2, 'IN', 20, 'Restocked from supplier'),
(3, 'OUT', 1, 'Sold to customer'),
(1, 'IN', 50, 'New stock delivery');
