<?php
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: ' . rtrim(str_replace($_SERVER['DOCUMENT_ROOT'], '', dirname(__DIR__)), '/') . '/auth/login.php'); exit; }
if ($_SESSION['role'] !== 'admin') { header('Location: index.php'); exit; }

require_once __DIR__ . '/../config/Database.php';
require_once __DIR__ . '/../classes/Medicine.php';

$errors = []; $v = ['name'=>'','price'=>'','quantity'=>'','expiry_date'=>''];
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $v = array_map('trim', $_POST);
    if (!$v['name'])                                      $errors[] = 'Medicine name is required.';
    if (!is_numeric($v['price'])   || $v['price']<0)      $errors[] = 'Valid price is required.';
    if (!is_numeric($v['quantity'])|| $v['quantity']<0)   $errors[] = 'Valid quantity is required.';
    if (!$v['expiry_date'])                               $errors[] = 'Expiry date is required.';
    if (!$errors) {
        (new Medicine())->create($v['name'],(float)$v['price'],(int)$v['quantity'],$v['expiry_date']);
        $_SESSION['flash']=['type'=>'success','msg'=>"Medicine '{$v['name']}' added."];
        header('Location: index.php'); exit;
    }
}
$pageTitle = 'Add Medicine';
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
?>

<main class="p-6">
  <div class="flex items-center justify-between mb-6">
    <div>
      <h2 class="text-2xl font-bold text-slate-900">Add New Medicine</h2>
      <p class="text-slate-500 text-sm mt-0.5">Fill in the details below</p>
    </div>
    <a href="index.php" class="inline-flex items-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm font-semibold px-4 py-2.5 rounded-xl transition-colors">← Back</a>
  </div>

  <?php foreach ($errors as $e): ?>
  <div class="mb-4 bg-red-50 border border-red-200 rounded-xl px-4 py-3 text-sm text-red-700 flex items-center gap-2">⚠️ <?= htmlspecialchars($e) ?></div>
  <?php endforeach; ?>

  <div class="bg-white rounded-2xl border border-slate-100 shadow-sm max-w-xl">
    <div class="px-6 py-4 border-b border-slate-100">
      <h3 class="font-bold text-slate-800">💊 Medicine Details</h3>
    </div>
    <div class="px-6 py-6">
      <form method="POST" class="space-y-5">
        <div>
          <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Medicine Name *</label>
          <input type="text" name="name" required autofocus value="<?= htmlspecialchars($v['name']) ?>"
                 placeholder="e.g. Paracetamol 500mg"
                 class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"/>
        </div>
        <div class="grid grid-cols-2 gap-4">
          <div>
            <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Price (USD) *</label>
            <input type="number" name="price" step="0.01" min="0" required value="<?= htmlspecialchars($v['price']) ?>"
                   placeholder="0.00"
                   class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"/>
          </div>
          <div>
            <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Quantity *</label>
            <input type="number" name="quantity" min="0" required value="<?= htmlspecialchars($v['quantity']) ?>"
                   placeholder="0"
                   class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"/>
          </div>
        </div>
        <div>
          <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Expiry Date *</label>
          <input type="date" name="expiry_date" required value="<?= htmlspecialchars($v['expiry_date']) ?>"
                 class="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"/>
        </div>
        <div class="flex gap-3 pt-2 border-t border-slate-100">
          <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-6 py-2.5 rounded-xl text-sm transition-colors shadow-sm">＋ Add Medicine</button>
          <a href="index.php" class="bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold px-6 py-2.5 rounded-xl text-sm transition-colors">Cancel</a>
        </div>
      </form>
    </div>
  </div>
</main>

<?php include __DIR__ . '/../includes/footer.php'; ?>
