<?php
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: ' . rtrim(str_replace($_SERVER['DOCUMENT_ROOT'], '', dirname(__DIR__)), '/') . '/auth/login.php'); exit; }

require_once __DIR__ . '/../config/Database.php';
require_once __DIR__ . '/../classes/Medicine.php';

$medicine  = new Medicine();
$search    = trim($_GET['search'] ?? '');
$medicines = $search ? $medicine->search($search) : $medicine->getAll();

$flash = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);
$pageTitle = 'Medicines';
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
?>

<main class="p-6 space-y-5">

  <div class="flex items-start justify-between">
    <div>
      <h2 class="text-2xl font-bold text-slate-900">Medicine Inventory</h2>
      <p class="text-slate-500 text-sm mt-0.5"><?= count($medicines) ?> medicines found</p>
    </div>
    <?php if ($_SESSION['role']==='admin'): ?>
    <a href="create.php" class="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold px-4 py-2.5 rounded-xl shadow transition-colors">＋ Add Medicine</a>
    <?php endif; ?>
  </div>

  <?php if ($flash): ?>
  <div class="alert-auto px-4 py-3 rounded-xl text-sm font-medium flex items-center gap-2
    <?= $flash['type']==='success' ? 'bg-green-50 border border-green-200 text-green-800' : 'bg-red-50 border border-red-200 text-red-800' ?>">
    <?= $flash['type']==='success' ? '✅' : '❌' ?> <?= htmlspecialchars($flash['msg']) ?>
  </div>
  <?php endif; ?>

  <!-- Search -->
  <div class="bg-white rounded-2xl border border-slate-100 shadow-sm p-4">
    <form method="GET" class="flex gap-3">
      <div class="relative flex-1 max-w-md">
        <span class="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">🔍</span>
        <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Search medicines…"
               class="w-full pl-9 pr-4 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"/>
      </div>
      <button class="bg-slate-800 hover:bg-slate-900 text-white text-sm font-semibold px-4 py-2.5 rounded-xl transition-colors">Search</button>
      <?php if ($search): ?><a href="index.php" class="bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm font-semibold px-4 py-2.5 rounded-xl transition-colors">Clear</a><?php endif; ?>
    </form>
  </div>

  <?php if (empty($medicines)): ?>
  <div class="bg-white rounded-2xl border border-slate-100 shadow-sm py-20 text-center">
    <div class="text-5xl mb-4">💊</div>
    <div class="text-lg font-bold text-slate-700 mb-1">No medicines found</div>
    <div class="text-slate-400 text-sm"><?= $search ? 'Try a different search.' : 'Add your first medicine.' ?></div>
    <?php if (!$search && $_SESSION['role']==='admin'): ?>
    <a href="create.php" class="inline-block mt-4 bg-blue-600 text-white text-sm font-semibold px-5 py-2.5 rounded-xl">Add Medicine</a>
    <?php endif; ?>
  </div>

  <?php else: ?>
  <div class="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
    <div class="overflow-x-auto">
      <table class="w-full text-sm">
        <thead class="bg-slate-50 text-xs text-slate-500 uppercase tracking-wider border-b border-slate-100">
          <tr>
            <th class="px-5 py-3.5 text-left font-semibold">#</th>
            <th class="px-5 py-3.5 text-left font-semibold">Name</th>
            <th class="px-5 py-3.5 text-left font-semibold">Price</th>
            <th class="px-5 py-3.5 text-left font-semibold">Stock</th>
            <th class="px-5 py-3.5 text-left font-semibold">Expiry</th>
            <th class="px-5 py-3.5 text-left font-semibold">Status</th>
            <?php if ($_SESSION['role']==='admin'): ?><th class="px-5 py-3.5 text-left font-semibold">Actions</th><?php endif; ?>
          </tr>
        </thead>
        <tbody class="divide-y divide-slate-50">
          <?php foreach ($medicines as $i => $med):
            $isOut   = $med['quantity'] == 0;
            $isLow   = $med['quantity'] <= 15 && !$isOut;
            $exp     = new DateTime($med['expiry_date']);
            $diff    = (int)(new DateTime())->diff($exp)->format('%R%a');
            $expired = $diff < 0;
            $expSoon = $diff >= 0 && $diff <= 60;
          ?>
          <tr class="hover:bg-slate-50 transition-colors">
            <td class="px-5 py-3.5 text-slate-400 text-xs"><?= $i+1 ?></td>
            <td class="px-5 py-3.5 font-semibold text-slate-900"><?= htmlspecialchars($med['name']) ?></td>
            <td class="px-5 py-3.5 font-bold text-slate-800">$<?= number_format($med['price'],2) ?></td>
            <td class="px-5 py-3.5">
              <span class="font-semibold <?= $isOut ? 'text-red-600' : ($isLow ? 'text-amber-600' : 'text-slate-800') ?>">
                <?= $med['quantity'] ?>
              </span>
              <span class="text-slate-400 text-xs ml-1">units</span>
            </td>
            <td class="px-5 py-3.5 text-slate-500 text-xs"><?= date('M d, Y', strtotime($med['expiry_date'])) ?></td>
            <td class="px-5 py-3.5">
              <?php if ($isOut):    echo '<span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-red-100 text-red-700">Out of Stock</span>';
              elseif ($expired):    echo '<span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-red-100 text-red-700">Expired</span>';
              elseif ($expSoon):    echo '<span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-100 text-amber-700">Expiring Soon</span>';
              elseif ($isLow):      echo '<span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-100 text-amber-700">Low Stock</span>';
              else:                 echo '<span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-green-100 text-green-700">In Stock</span>';
              endif; ?>
            </td>
            <?php if ($_SESSION['role']==='admin'): ?>
            <td class="px-5 py-3.5">
              <div class="flex items-center gap-2">
                <a href="edit.php?id=<?= $med['id'] ?>"
                   class="inline-flex items-center gap-1 text-xs font-semibold text-blue-600 hover:text-blue-800 bg-blue-50 hover:bg-blue-100 px-3 py-1.5 rounded-lg transition-colors">
                  ✏️ Edit
                </a>
                <form method="POST" action="delete.php" onsubmit="return confirm('Delete <?= htmlspecialchars(addslashes($med['name'])) ?>?')">
                  <input type="hidden" name="id" value="<?= $med['id'] ?>">
                  <button type="submit"
                    class="inline-flex items-center gap-1 text-xs font-semibold text-red-600 hover:text-red-800 bg-red-50 hover:bg-red-100 px-3 py-1.5 rounded-lg transition-colors">
                    🗑 Delete
                  </button>
                </form>
              </div>
            </td>
            <?php endif; ?>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
  <?php endif; ?>

</main>

<?php include __DIR__ . '/../includes/footer.php'; ?>
