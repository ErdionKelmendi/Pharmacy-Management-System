<?php
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: ' . rtrim(str_replace($_SERVER['DOCUMENT_ROOT'], '', dirname(__DIR__)), '/') . '/auth/login.php'); exit; }
if ($_SESSION['role'] !== 'admin') { header('Location: index.php'); exit; }
require_once __DIR__ . '/../config/Database.php';
require_once __DIR__ . '/../classes/Medicine.php';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $id=(int)($_POST['id']??0);
    if ($id>0) {
        $m=new Medicine(); $med=$m->getById($id);
        if ($med) { $m->delete($id); $_SESSION['flash']=['type'=>'success','msg'=>"Medicine '{$med['name']}' deleted."]; }
        else { $_SESSION['flash']=['type'=>'error','msg'=>'Medicine not found.']; }
    }
}
header('Location: index.php'); exit;
