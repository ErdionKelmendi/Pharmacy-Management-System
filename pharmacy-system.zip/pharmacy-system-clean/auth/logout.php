<?php
session_start();
session_destroy();
header('Location: ' . rtrim(str_replace($_SERVER['DOCUMENT_ROOT'], '', dirname(__DIR__)), '/') . '/auth/login.php');
exit;
?>